---
name: quote-paraphrase-extraction
description: Extract relevant verbatim passages from user-supplied scholarly sources, check quotations against the originals, pair each quotation with a faithful paraphrase and page-specific APA citation, and make reusable, dated evidence CSVs and optional Colab verification notebooks. Use for research questions, literature synthesis, evidence-based practice, and source-to-claim audit trails.
---

# Quote and paraphrase extraction

Build a source-to-claim trail for the user's precise research question. Treat the original source as authoritative; never manufacture a quotation, page, author, title, DOI, or finding.

## Source review

1. Retain the user's research question **verbatim**. Read the actual supplied source, including its tables, methods, qualifications, and limitations. Inspect rendered pages when PDF extraction obscures formatting. Obtain bibliographic metadata from the original and check printed page numbering. If the source is missing, seek it rather than generating quotations from a citation or abstract.
2. Find each *relevant* passage and transcribe a contiguous, sufficient quotation exactly as printed, without tidying spelling, silently joining fragments, or using editorial ellipses as if they were source text. Record the PDF's 1-based page index separately from the printed page number. For tables, keep each quoted row's label and description together, and distinguish proposed taxonomies from observed study results.
3. Write a narrow, independently worded paraphrase grounded in the **whole passage**, preserving qualifiers, population, outcome, and the source's level of certainty. Explain a reported claim as the authors' finding when appropriate; do not extend it to other populations. If the source quotes another work, do not attribute that original work's result to the current paper.
4. Pair *each* quotation and *each* paraphrase with an APA author-date citation and printed page number. Include the full verified APA reference and DOI/URL in the evidence data. Do not substitute a PDF page index for a printed citation page. If no printed pagination exists, use APA-appropriate section/paragraph locators and note the choice.
5. Verify the extracted words on the cited PDF page, preferably both with a script and by looking at the page image. Check quoted words, punctuation, and page number separately. Review the original passage to assess the paraphrase; a positive text match alone is insufficient. Mark OCR-only, ambiguous, or unverified evidence for manual review and make no unsupported exact-match claim.

## CSV deliverable

Create one UTF-8-with-BOM CSV per research question and source, named `YYYY-MM-DD_quest_abbrev_source_abbrev_evidence.csv`. Use the **user's local date of extraction**, unless they specified another relevant project date. Choose short stable abbreviations; for example `2026-11-09_LLMTasks_Bodonhelyi2026_evidence.csv`. Preserve that date/question association when revising an existing file; avoid changing it to the revision date automatically.

Use [evidence_template.csv](assets/evidence_template.csv) as the column template. Include `question_id` (date plus question abbreviation) and the *full original wording* in `research_question` on **every row**. Give each passage a stable unique `evidence_id`. Preserve the source's exact uploaded PDF basename in `source_filename` for automated checks; include `source_id`, `source_doi`, `apa_reference`, `printed_page`, `pdf_page`, `source_location`, `intent_category` (or another context category), `task_type` (or another topic-specific code), `quote_exact`, `quote_apa_citation`, `paraphrase`, `paraphrase_apa_citation`, `evidence_role`, and `notes`. Change topical column labels only if this improves the project, while retaining the required verification and provenance fields. One quote and its linked paraphrase per row; separate different passages even if they support the same claim.

Do not fill rows with only table-label fragments if a fuller passage is available. Include meaningful methodological and limitation passages when they affect interpretation. Record source-derived categories and empirical observations with different `evidence_role` values. Do not treat the list as exhaustive merely to reach a predetermined row count. For multiple sources, keep source-specific CSVs and, if requested, concatenate them into a combined long-form table without dropping question, source, page, or stable evidence IDs.

## Check and deliver

Run `python scripts/verify_quotes.py EVIDENCE.csv --pdf-dir PDF_DIRECTORY --out AUDIT.csv` against PDFs on disk. The script uses PyMuPDF (`python -m pip install pymupdf` if missing) and classifies exact matches, whitespace-only matches, wrong-page matches, missing PDFs, and absent quotations. Inspect every non-exact result and recheck exact results visually when layout or context matters. It cannot judge paraphrase fidelity or whether citations use the correct printed page.

When the user wants a Google Colab verifier, provide the generic [Colab notebook](assets/Verify_PDF_Quotations_Colab.ipynb). It accepts any one dated evidence CSV and its matching PDF files in one upload; it saves an annotated evidence CSV and a quotation audit. Keep the notebook compatible with the CSV template when adding columns. Explain that PDF scans need OCR and that any matched quotation still needs a human context check.

When creating downloadable files, save them persistently through the available file workflow. Preserve the identity of an existing evidence CSV when revising it. In the response, distinguish verified source quotations from interpretive paraphrases and briefly flag material limitations.
