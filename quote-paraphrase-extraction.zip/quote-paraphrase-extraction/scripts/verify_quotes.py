#!/usr/bin/env python3
"""Check one-quote-per-row evidence CSV against original PDF text layers."""

import argparse
import csv
import unicodedata
from pathlib import Path

try:
    import fitz
except ImportError as exc:
    raise SystemExit('PyMuPDF is required: python -m pip install pymupdf') from exc


def normalize_whitespace(s):
    return ' '.join(unicodedata.normalize('NFKC', s).split())


def check(quote, text):
    if quote in text:
        return 'exact_match'
    if normalize_whitespace(quote) in normalize_whitespace(text):
        return 'whitespace_match'
    return ''


def verify_rows(rows, pdf_dir):
    cache = {}
    seen = set()
    for row in rows:
        evidence_id = row['evidence_id']
        if evidence_id in seen:
            raise ValueError(f'Duplicate evidence_id: {evidence_id}')
        seen.add(evidence_id)
        quote = row['quote_exact']
        name = row['source_filename']
        result = dict(row)
        result.update(verification_status='', found_pdf_pages='', verification_detail='')
        path = pdf_dir / name
        if not quote.strip():
            result['verification_status'] = 'empty_quote'
        elif Path(name).name != name:
            result['verification_status'] = 'invalid_source_filename'
        elif not path.is_file():
            result['verification_status'] = 'missing_pdf'
        else:
            if name not in cache:
                with fitz.open(path) as pdf:
                    cache[name] = [page.get_text(sort=True) for page in pdf]
            pages = cache[name]
            try:
                page_no = int(row['pdf_page'])
                if not 1 <= page_no <= len(pages):
                    raise ValueError('out of range')
            except (ValueError, TypeError):
                result['verification_status'] = 'invalid_pdf_page'
                result['verification_detail'] = f'Valid PDF pages: 1–{len(pages)}'
            else:
                status = check(quote, pages[page_no - 1])
                if status:
                    result['verification_status'] = status
                    result['found_pdf_pages'] = str(page_no)
                else:
                    hits = [(i, check(quote, text)) for i, text in enumerate(pages, 1)
                            if i != page_no]
                    hits = [(i, match) for i, match in hits if match]
                    if hits:
                        result['verification_status'] = 'found_other_page'
                        result['found_pdf_pages'] = ';'.join(str(i) for i, _ in hits)
                        result['verification_detail'] = '; '.join(
                            f'PDF p. {i}: {match}' for i, match in hits)
                    else:
                        result['verification_status'] = 'not_found'
                        result['verification_detail'] = 'Inspect text layer, quote, page, or OCR'
        yield result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_csv', type=Path)
    parser.add_argument('--pdf-dir', type=Path, default=Path('.'),
                        help='Directory containing the original PDFs')
    parser.add_argument('--out', type=Path, default=None,
                        help='Output CSV (default: <input-stem>_verified.csv)')
    args = parser.parse_args()
    with args.evidence_csv.open('r', encoding='utf-8-sig', newline='') as src:
        reader = csv.DictReader(src)
        required = {'evidence_id', 'source_filename', 'quote_exact', 'pdf_page',
                    'printed_page', 'research_question'}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise SystemExit(f'Missing required columns: {sorted(missing)}')
        rows = list(reader)
        fields = list(reader.fieldnames) + [
            'verification_status', 'found_pdf_pages', 'verification_detail']
    out = args.out or args.evidence_csv.with_name(args.evidence_csv.stem + '_verified.csv')
    checked = list(verify_rows(rows, args.pdf_dir))
    with out.open('w', encoding='utf-8-sig', newline='') as dest:
        writer = csv.DictWriter(dest, fieldnames=fields)
        writer.writeheader()
        writer.writerows(checked)
    counts = {}
    for row in checked:
        status = row['verification_status']
        counts[status] = counts.get(status, 0) + 1
    print(f'{out}: {len(checked)} rows; {counts}')
    print('Text matching does not validate printed page numbers, source context, or paraphrases.')


if __name__ == '__main__':
    main()
