#!/usr/bin/env python3
"""Inspect evidence CSV files for paraphrase synthesis."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

REQUIRED = ("evidence_id", "research_question", "paraphrase", "paraphrase_apa_citation")


def load(paths: list[Path]) -> tuple[list[dict[str, str]], list[str]]:
    rows: list[dict[str, str]] = []
    errors: list[str] = []
    seen: dict[str, Path] = {}
    for path in paths:
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                headers = reader.fieldnames or []
                missing = [name for name in REQUIRED if name not in headers]
                if missing:
                    errors.append(f"{path}: missing columns: {', '.join(missing)}")
                    continue
                for line_number, raw in enumerate(reader, 2):
                    row = {key: (value or "").strip() for key, value in raw.items() if key is not None}
                    evidence_id = row.get("evidence_id", "")
                    if not evidence_id:
                        errors.append(f"{path}:{line_number}: blank evidence_id")
                        continue
                    if evidence_id in seen:
                        errors.append(f"{path}:{line_number}: duplicate evidence_id {evidence_id} (first in {seen[evidence_id]})")
                    else:
                        seen[evidence_id] = path
                    row["_input_file"] = path.name
                    rows.append(row)
        except (OSError, csv.Error) as exc:
            errors.append(f"{path}: {exc}")
    return rows, errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--compact", action="store_true", help="Print one tab-delimited line per evidence row after the summary.")
    args = parser.parse_args()

    rows, errors = load(args.inputs)
    questions = Counter(row.get("research_question", "") for row in rows)
    sources = Counter((row.get("source_id") or row.get("source_filename") or row["_input_file"]) for row in rows)
    topics = Counter(row.get("intent_category", "") for row in rows if row.get("intent_category"))
    tasks = Counter(row.get("task_type", "") for row in rows if row.get("task_type"))
    summary = {
        "input_files": [str(path) for path in args.inputs],
        "evidence_rows": len(rows),
        "source_count": len(sources),
        "research_questions": dict(questions),
        "sources": dict(sources),
        "intent_categories": dict(topics),
        "task_types": dict(tasks),
        "missing_paraphrases": [row["evidence_id"] for row in rows if not row.get("paraphrase")],
        "missing_citations": [row["evidence_id"] for row in rows if not row.get("paraphrase_apa_citation")],
        "errors": errors,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))

    if args.compact:
        for row in rows:
            fields = [
                row["evidence_id"],
                row.get("source_id") or row.get("source_filename") or row["_input_file"],
                row.get("intent_category", ""),
                row.get("task_type", ""),
                row.get("paraphrase", "").replace("\n", " "),
                row.get("paraphrase_apa_citation", ""),
            ]
            print("\t".join(fields))

    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
