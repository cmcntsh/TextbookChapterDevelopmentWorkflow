#!/usr/bin/env python3
"""Validate a synthesis-statements CSV against its evidence CSV files."""

from __future__ import annotations

import argparse
import csv
import re
import sys
from collections import Counter
from pathlib import Path

EVIDENCE_REQUIRED = ("evidence_id", "research_question", "paraphrase", "paraphrase_apa_citation")
OUTPUT_REQUIRED = (
    "synthesis_id",
    "research_question",
    "main_topic",
    "subtopic",
    "synthesis_type",
    "synthesis_statement",
    "supporting_evidence_ids",
    "supporting_source_count",
    "supporting_evidence_count",
    "synthesis_apa_citation",
    "explanatory_notes",
)
ALLOWED_TYPES = {"Agreement", "Disagreement", "Additional insight"}


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        rows = [{key: (value or "").strip() for key, value in row.items() if key is not None} for row in reader]
    return headers, rows


def source_key(row: dict[str, str], fallback: str) -> str:
    return row.get("source_id") or row.get("source_filename") or fallback


def citation_body(value: str) -> str:
    return re.sub(r"^\(|\)$", "", value.strip())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", nargs="+", required=True, type=Path)
    parser.add_argument("--synthesis", required=True, type=Path)
    args = parser.parse_args()

    errors: list[str] = []
    warnings: list[str] = []
    evidence: dict[str, dict[str, str]] = {}

    for path in args.evidence:
        try:
            headers, rows = read_csv(path)
        except (OSError, csv.Error) as exc:
            errors.append(f"{path}: {exc}")
            continue
        missing = [name for name in EVIDENCE_REQUIRED if name not in headers]
        if missing:
            errors.append(f"{path}: missing evidence columns: {', '.join(missing)}")
            continue
        for line_number, row in enumerate(rows, 2):
            evidence_id = row.get("evidence_id", "")
            if not evidence_id:
                errors.append(f"{path}:{line_number}: blank evidence_id")
                continue
            if evidence_id in evidence:
                errors.append(f"{path}:{line_number}: duplicate evidence_id {evidence_id}")
                continue
            row["_source_key"] = source_key(row, path.name)
            evidence[evidence_id] = row

    try:
        headers, synthesis_rows = read_csv(args.synthesis)
    except (OSError, csv.Error) as exc:
        errors.append(f"{args.synthesis}: {exc}")
        headers, synthesis_rows = [], []

    if headers != list(OUTPUT_REQUIRED):
        errors.append(f"{args.synthesis}: columns must exactly match the required order")

    seen_synthesis_ids: set[str] = set()
    type_counts: Counter[str] = Counter()
    for line_number, row in enumerate(synthesis_rows, 2):
        synthesis_id = row.get("synthesis_id", "")
        prefix = f"{args.synthesis}:{line_number}:{synthesis_id or '[blank]'}"
        if not synthesis_id:
            errors.append(f"{prefix}: blank synthesis_id")
        elif synthesis_id in seen_synthesis_ids:
            errors.append(f"{prefix}: duplicate synthesis_id")
        seen_synthesis_ids.add(synthesis_id)

        synthesis_type = row.get("synthesis_type", "")
        type_counts[synthesis_type] += 1
        if synthesis_type not in ALLOWED_TYPES:
            errors.append(f"{prefix}: invalid synthesis_type {synthesis_type!r}")

        for field in ("research_question", "main_topic", "synthesis_statement", "supporting_evidence_ids", "synthesis_apa_citation"):
            if not row.get(field, ""):
                errors.append(f"{prefix}: blank {field}")

        ids = [item.strip() for item in row.get("supporting_evidence_ids", "").split(";") if item.strip()]
        if not ids:
            continue
        if len(ids) != len(set(ids)):
            errors.append(f"{prefix}: duplicate supporting evidence IDs")
        missing_ids = [evidence_id for evidence_id in ids if evidence_id not in evidence]
        if missing_ids:
            errors.append(f"{prefix}: unknown evidence IDs: {', '.join(missing_ids)}")
            continue
        supporting = [evidence[evidence_id] for evidence_id in ids]

        try:
            stated_evidence_count = int(row.get("supporting_evidence_count", ""))
            if stated_evidence_count != len(ids):
                errors.append(f"{prefix}: supporting_evidence_count should be {len(ids)}")
        except ValueError:
            errors.append(f"{prefix}: supporting_evidence_count is not an integer")

        expected_source_count = len({item["_source_key"] for item in supporting})
        try:
            stated_source_count = int(row.get("supporting_source_count", ""))
            if stated_source_count != expected_source_count:
                errors.append(f"{prefix}: supporting_source_count should be {expected_source_count}")
        except ValueError:
            errors.append(f"{prefix}: supporting_source_count is not an integer")

        questions = {item.get("research_question", "") for item in supporting}
        if questions != {row.get("research_question", "")}:
            errors.append(f"{prefix}: research question does not match all supporting rows")

        citation = citation_body(row.get("synthesis_apa_citation", ""))
        for evidence_id, item in zip(ids, supporting):
            source_citation = citation_body(item.get("paraphrase_apa_citation", ""))
            if not source_citation:
                warnings.append(f"{prefix}: evidence {evidence_id} has no paraphrase citation")
            elif source_citation not in citation:
                errors.append(f"{prefix}: citation omits evidence {evidence_id}: {source_citation}")

        if synthesis_type == "Agreement" and expected_source_count < 2:
            errors.append(f"{prefix}: Agreement requires at least two distinct sources")
        if synthesis_type == "Disagreement" and expected_source_count < 2:
            warnings.append(f"{prefix}: single-source disagreement; confirm this is an internal divergence")
        if synthesis_type == "Additional insight" and expected_source_count < 2 and not row.get("explanatory_notes", ""):
            warnings.append(f"{prefix}: single-source additional insight should be qualified in notes")

    print(f"Evidence rows: {len(evidence)}")
    print(f"Synthesis rows: {len(synthesis_rows)}")
    print("Synthesis types: " + ", ".join(f"{key}={value}" for key, value in sorted(type_counts.items())))
    for warning in warnings:
        print(f"WARNING: {warning}")
    for error in errors:
        print(f"ERROR: {error}")
    print(f"Validation result: {'FAIL' if errors else 'PASS'} ({len(errors)} errors, {len(warnings)} warnings)")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
