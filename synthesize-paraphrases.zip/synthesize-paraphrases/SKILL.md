---
name: synthesize-paraphrases
description: Synthesize paraphrased research evidence from one or more CSV files into traceable cross-source statements of agreement, disagreement or divergence, and additional insights. Use when asked to compare paraphrases, identify convergent and divergent findings, derive themes or subgroups, preserve the original research question, link each synthesis statement to evidence IDs, create page-specific grouped APA citations, or produce a synthesis-statements CSV for literature reviews, evidence tables, or audit trails.
---

# Synthesize Paraphrases

Create a defensible synthesis from evidence-table paraphrases while preserving row-level traceability. Treat semantic synthesis as a reasoning task and use the bundled scripts for deterministic inventory and validation.

## Required inputs

Accept one combined CSV or several compatible evidence CSVs. Require these columns:

- `evidence_id`
- `research_question`
- `paraphrase`
- `paraphrase_apa_citation`

Use `source_id`, `intent_category`, `task_type`, `evidence_role`, and `notes` when present. Read [references/schema.md](references/schema.md) when schemas differ, multiple research questions occur, or the output fields need clarification.

Do not alter the source evidence files. Normalize rows by column name, not position. Stop and explain the problem if evidence IDs are blank, duplicated, or ambiguous.

## Workflow

### 1. Inspect and inventory the evidence

Run:

```bash
python3 scripts/evidence_inventory.py INPUT.csv [MORE_INPUTS.csv ...]
```

Confirm row and source counts, research questions, topic labels, missing paraphrases or citations, duplicate IDs, and study contexts affecting comparison.

If inputs contain different research questions, create a separate synthesis for each question unless the user explicitly asks for a comparison across questions.

### 2. Build concept clusters

Group paraphrases by underlying claim rather than exact wording. Keep distinctions that change meaning:

- presence of a task versus reported prevalence;
- user goal versus model action;
- advice versus delegated execution;
- observed use versus proposed or potential use;
- broad task family versus domain-specific subtype;
- task classification versus occupation, adoption, quality, or outcome;
- counts or percentages with different denominators.

Use source context to avoid false equivalence. One evidence row may support more than one synthesis statement when it genuinely bears on multiple claims.

### 3. Draft synthesis statements

Assign one exact value:

- `Agreement`: two or more distinct sources express materially similar claims.
- `Disagreement`: sources directly conflict or report meaningfully divergent rankings, prevalence, framing, scope, or classification. Explain likely reasons when supported.
- `Additional insight`: a cross-cutting pattern, subgroup, boundary condition, methodological subtlety, or more comprehensive interpretation. A single source may support a unique subgroup insight, but identify that limitation in notes.

Do not force disagreement merely because sources use different labels. Do not erase real divergence by averaging incompatible estimates. Phrase statements at the narrowest level fully supported by the cited paraphrases.

### 4. Select supporting evidence

For each statement:

1. Include every evidence ID needed to support the full claim.
2. Prefer multiple independent sources for agreement statements.
3. Include evidence from each side of a disagreement.
4. Include the row containing any count, percentage, rank, limitation, subgroup, or methodological qualifier.
5. Remove IDs that are merely topical but do not support the wording.

Use semicolon-space delimiters in `supporting_evidence_ids`.

### 5. Construct the APA citation

Build `synthesis_apa_citation` from the exact `paraphrase_apa_citation` values of the supporting rows:

- retain page, section, figure, abstract, or other locators exactly as supplied;
- deduplicate identical citations;
- sort works alphabetically within one parenthetical citation;
- never invent a page number or locator;
- use the evidence row's citation rather than reconstructing authorship from memory.

If an input citation lacks a locator, preserve it and flag the limitation in `explanatory_notes`.

### 6. Create the CSV

Use these columns in order:

1. `synthesis_id`
2. `research_question`
3. `main_topic`
4. `subtopic`
5. `synthesis_type`
6. `synthesis_statement`
7. `supporting_evidence_ids`
8. `supporting_source_count`
9. `supporting_evidence_count`
10. `synthesis_apa_citation`
11. `explanatory_notes`

Use stable IDs such as `SYN001`. Keep one statement per row. Use valid UTF-8 CSV quoting.

Default filename:

```text
YYYY-MM-DD_<question-abbreviation>_synthesis_statements.csv
```

### 7. Validate before delivery

Run:

```bash
python3 scripts/validate_synthesis.py \
  --evidence INPUT.csv [MORE_INPUTS.csv ...] \
  --synthesis OUTPUT.csv
```

Resolve every error and review warnings. The script verifies schema, IDs, counts, research-question consistency, and citation traceability; it does not replace semantic review.

Manually confirm that each statement answers the question; agreement is genuinely cross-source; disagreement gives both sides; prevalence remains context-bound; notes identify noncomparability or single-source insights; and important themes remain represented without manufacturing uniformity.

## Quality rules

- Synthesize; do not concatenate paraphrases.
- Prefer precise statements over broad claims with long citation lists.
- Separate task occurrence from frequency, effectiveness, accuracy, safety, adoption, and impact.
- Treat taxonomies as analytical frameworks, not automatically as prevalence evidence.
- Treat platform-specific distributions as context-bound unless evidence supports generalization.
- Preserve meaningful minority, long-tail, and domain-specific uses.
- Use `Disagreement` for conceptual divergence when appropriate, but note when it is not a direct empirical contradiction.
- Do not cite a source merely because it discusses the same topic.

## Bundled resources

- `scripts/evidence_inventory.py`: inspect evidence CSVs and produce a compact inventory.
- `scripts/validate_synthesis.py`: validate a synthesis CSV against its evidence.
- `references/schema.md`: schemas, synthesis-type definitions, and citation rules.
