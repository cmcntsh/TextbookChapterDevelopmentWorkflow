# Evidence and synthesis CSV schema

## Input evidence

Required columns:

| Column | Requirement |
| --- | --- |
| `evidence_id` | Nonblank and unique across all supplied files. |
| `research_question` | Original question the paraphrase was collected to answer. |
| `paraphrase` | Faithful source-grounded restatement of the evidence. |
| `paraphrase_apa_citation` | In-text APA citation with a page or other source locator when available. |

Recommended columns include `source_id`, `source_filename`, `apa_reference`, `intent_category`, `task_type`, `evidence_role`, and `notes`.

When `source_id` is absent, derive a provisional source key only for source-count validation and document the method. Do not overwrite the source file.

## Output synthesis

| Column | Content |
| --- | --- |
| `synthesis_id` | Stable unique ID such as `SYN001`. |
| `research_question` | Exact original research question. |
| `main_topic` | Broad subject covered by the statement. |
| `subtopic` | Narrower subject; leave blank only when none is meaningful. |
| `synthesis_type` | Exact value: `Agreement`, `Disagreement`, or `Additional insight`. |
| `synthesis_statement` | New cross-source synthesis claim. |
| `supporting_evidence_ids` | Semicolon-space-delimited evidence IDs. |
| `supporting_source_count` | Count of distinct supporting sources. |
| `supporting_evidence_count` | Count of supporting evidence IDs. |
| `synthesis_apa_citation` | Grouped citation derived from the supporting rows. |
| `explanatory_notes` | Comparability limits, subgroup cautions, or interpretive qualifications. |

## Synthesis-type decision rules

### Agreement

Use when at least two distinct sources support the same material proposition. Similarity may exist beneath different labels, but the statement must not exceed their shared meaning.

### Disagreement

Use for direct contradictions, different reported rankings or prevalence patterns, alternative conceptualizations, or taxonomy differences that materially change interpretation.

State whether the difference is a direct contradiction or a context-dependent divergence. Do not compare percentages with different denominators as if they estimate one population.

### Additional insight

Use for subgroup patterns, methodological effects, workflow sequences, distinctions such as user goal versus model action, domain-specific decomposition, boundaries on generalizability, and long-tail uses.

## Citation construction

Given supporting citations such as:

```text
(Author et al., 2024, p. 10)
(Other et al., 2025, Section 3.2)
```

Create one grouped citation:

```text
(Author et al., 2024, p. 10; Other et al., 2025, Section 3.2)
```

Preserve each locator and deduplicate identical citations. If several IDs share the same citation and locator, one occurrence is sufficient.

## Common errors

- Calling a single-source observation an agreement.
- Treating absence from one taxonomy as proof a task does not occur.
- Labeling different terminology as disagreement without a material difference.
- Combining platform-specific percentages into a pooled estimate.
- Citing a broad source-level reference without the paraphrase locator.
- Listing IDs that discuss the topic but do not support the full statement.
