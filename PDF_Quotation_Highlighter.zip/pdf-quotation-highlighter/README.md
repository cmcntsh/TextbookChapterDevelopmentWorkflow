# PDF Quotation Highlighter

This browser-based app compares quotations in a CSV file with the extractable text of a PDF, shows matched passages on the rendered PDF page, and identifies quotations that need review. Files are processed in the browser and are not uploaded by the app.

## Quick start

1. Open `index.html` in a current version of Chrome, Edge, Firefox, or Safari.
2. Select a text-based PDF.
3. Select a CSV file containing a quotation column.
4. Choose **Match and highlight quotations**.
5. Select a quotation result to jump to its PDF page.

An internet connection is required when the app opens because it loads the PDF.js rendering engine from jsDelivr. No PDF or CSV content is sent to that service.

## CSV format

Recommended columns:

| Column | Purpose |
| --- | --- |
| `evidence_id` | Optional identifier displayed beside the result. |
| `quote` | Required verbatim quotation. The app also recognizes names such as `quotation`, `verbatim_quote`, `quote_raw_text`, `passage`, and `excerpt`. |
| `pdf_page` | Recommended 1-based PDF page used for navigation and initial matching. |
| `printed_page` | Optional page printed on the article, displayed for citation checking. |
| `apa_citation` | Optional source citation retained from the CSV. |

If the CSV contains only a `page` column, the app interprets it as the PDF page. CSV values containing commas or quotation marks must follow standard CSV quoting rules.

## GitHub Pages

1. Create a GitHub repository and add the contents of this folder at its root.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select the branch containing `index.html`, choose the root folder, and save.

## Matching behavior

- The app first tries a case-insensitive match after normalizing Unicode quotation marks, dashes, whitespace, and line-break hyphenation.
- If that fails, it tries a relaxed comparison that ignores punctuation and diacritics.
- When a valid `pdf_page` is supplied, that page is searched first. If the quotation is found elsewhere, the result reports the discrepancy.
- When no page is supplied, the entire PDF is searched.

## Limitations

- Scanned or image-only PDFs must be processed with OCR before this app can match their text.
- PDF text extraction order can differ from visual reading order in complex multi-column layouts.
- Highlights follow PDF text objects. A text object may contain surrounding characters, so a highlight can occasionally extend slightly beyond the quotation.
- Password-protected or malformed PDFs may not open.
- Matching is performed in the browser and may take time for very long PDFs or large quotation lists.

## Technology and privacy

The app uses Mozilla PDF.js 6.5.438 for PDF parsing and rendering. All application code and CSV parsing are contained in `index.html`; there is no server component, database, analytics service, or file upload endpoint.
